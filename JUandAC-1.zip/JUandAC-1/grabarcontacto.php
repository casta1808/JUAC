<?
echo '<br> Recibiendo petición';
$nombres=$_POST['nombres'];
$apellidos=$_POST['apellidos'];
$telefono=$_POST['telefono'];
$direccion=$_POST['direccion'];
$barrio=$_POST['barrio'];
$correo=$_POST['correo'];
$estado='activo';
echo '<br>nombres ' .$nombres;
echo '<br>apellidos ' .$apellidos;
echo '<br>telefono ' .$telefono;
echo '<br>direccion ' .$direccion;
echo '<br>barrio ' .$barrio;
echo '<br>correo ' .$correo;

if (empty ($nombres) || empty($apellidos) || empty($telefono) || empty($direccion) || empty($barrio) || empty($correo))
{
  echo '<br> los campos marcados con (*) son obligatorios';
} else{
include 'config/conexion.php';
if (!$con){
    die ("Error en la conexión");
  }
$sql="INSERT INTO tblclientes(nombres,apellidos,telefono,direccion,barrio,correo,estado) 
VALUES('$nombres','$apellidos''$telefono','$direccion','$barrio','$correo','$estado')";
echo '<br>'.$sql;
$consulta = mysqli_query($con,$sql) or die("Fallo en la inserción".mysqli_error($con));
mysqli_close ($con);
  }
?>
 
<meta http-equiv="refresh" content="1; url=index.php?msj=$msj">