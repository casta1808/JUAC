<?include 'head.php';?>
<section class="page-section" id="login">

<div class="container">
<h2 class="page-section-heading text-center text-uppercase text-secondary mb-0">REGISTRARSE</h2>
  <div class="divider-custom">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
  <?
  $msj=$_get['msj'];
echo ''.$msj
  ?>

 <form method="post" action="generarclave.php">

 <div class="form-group">
 <label for="telefono">Teléfono:</label>
 <input type="text"
 class="form-control"
 id="telefono"
 placeholder="telefono" name="telefono" required> </div>
   <div class="form-group">
 <label for="documento">Documento:</label>
 <input type="text"
 class="form-control"
 id="documento"
 placeholder="documento" name="documento" required> </div>
 <div class="form-group">
 <label for="correo">Correo:</label>
 <input type="email"
 class="form-control"
 id="correo"
 placeholder="Correo" name="correo" required> </div>
 <div class="form-group">
 <label for="nombre">Nombre:</label>
 <input type="text"
 class="form-control" id="nombre"
 placeholder="Nombre" name="nombre" required>
 </div>
 <div class="form-group">
 <label for="pwd">Contraseña:</label>
 <input type="password" class="form-control" id="pwd"
 placeholder="Enter password" name="pwd" required>
 </div>
 <div class="form-group">
 <label for="rpwd">Confirmar contraseña:</label>
 <input type="password" class="form-control" id="rpwd"
 placeholder="Enter password" name="rpwd" required>
 </div><br>
 <button type="submit" class="btn btn-primary">Enviar
 </button><br><br>
 </form></div>