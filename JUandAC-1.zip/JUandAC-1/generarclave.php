<div class="container-sm border">
<div class="form-group">

 <?
$msj="";
$telefono =$_POST['telefono'];
$documento =$_POST['documento'];
$correo =$_POST['correo'];
$nombre=$_POST['nombre'];
$clave=$_POST['pwd'];
$rclave=$_POST['rpwd'];
$perfil=0;
 /* echo '<br>'.$correo;
 echo '<br>'.$usuario;
 echo '<br>'.$clave;
 echo '<br>'.$rclave;*/
 if ($clave==$rclave){
 include 'config/conexion.php';
 $instruccion = "select * from tblusuario where correo='$correo'";
 $consulta = mysqli_query ($con, $instruccion)
 or die ("Fallo en la consulta correo");
 //or die mysqli_error($consulta);
 // Mostrar resultados de la consulta
 $nfilas = mysqli_num_rows ($consulta);
 if ($nfilas == 0)
 {
   // Correcciones 
 $salt = substr ($documento, 0, 2);
 $clave_crypt = crypt ($clave, $salt);
 $instruccion = "INSERT INTO tblusuario (nombre,contraseña,correo,telefono,documento,perfil) values ('$nombre', '$clave_crypt','$correo','$telefono','$documento','$perfil')";
 $consulta = mysqli_query ($con, $instruccion) or die ("Fallo en la inserción");
 mysqli_close ($con);

 echo '<div class="alert alert-success alert-dismissible">';
 echo '<button type="button" class="close" data-dismiss="alert">×</button>';
 echo '<strong>Usuario<br>'. $nombre. 'creado con éxito</strong> </div>';
   $msj="Usuario creado exitosamente";
 }else{
 echo '<div class="alert alert-danger alert-dismissible">';
 echo '<button type="button" class="close" data-dismiss="alert">×</button>';
 echo '<strong>Correo no válido</strong> </div>';
   $msj="<strong>Correo no válido</strong> </div>";
 } }else{
 echo '<div class="alert alert-danger alert-dismissible">';
 echo '<button type="button" class="close" data-dismiss="alert">×</button>';
 echo '<strong>Las claves no coinciden</strong> </div>';
   $msj="<strong>Las claves no coinciden</strong> </div>";
   
 }
 echo "<meta http-equiv='refresh' content='2;url=index.php'/>";
 //header('https://juandac-1.jhonatanusuga.repl.co/?msj=$msj'); 

?>
</div>
</div>