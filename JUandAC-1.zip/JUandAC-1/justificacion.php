<section class="page-section bg-primary text-white mb-0" id="justificacion">
            <div class="container">
                <!-- About Section Heading-->
                <h2 class="page-section-heading text-center text-uppercase text-white">JUSTIFICACIÓN</h2>
                <!-- Icon Divider-->
                <div class="divider-custom divider-light">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                <!-- About Section Content-->
                <div class="text-center">
                 Nuestro proyecto está basado en realizar bebidas saborizadas y micheladas con y sin alcohol. Utilizando también una cantidad de frutas la cual acompañaría de una manera excelente nuestras bebidas.</p>
                </div>
                <!-- About Section Button-->
                
            </div>
        </section>