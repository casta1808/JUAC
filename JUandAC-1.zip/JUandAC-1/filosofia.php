<section class="page-section bg-primary text-white mb-0" id="filosofia">
            <div class="container">
                <!-- About Section Heading-->
                <h2 class="page-section-heading text-center text-uppercase text-white">FILOSOFÍA</h2>
                <!-- Icon Divider-->
                <div class="divider-custom divider-light">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                <!-- About Section Content-->
                <div class="text-center">
                  En nuestra empresa tenemos claro que una buena atención al cliente habla bien de nosotros mismos, ya que para nosotros es sumamente importante que el cliente se sienta satisfecho ya que hacen parte de nosotros.Además, es para nosotros un gusto la carisma entre todo nuestro personal y nuestros clientes.</p>
                </div>
                <!-- About Section Button-->
                
            </div>
        </section>