-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: btnkw8xgenawfvi4xosn-mysql.services.clever-cloud.com:3306
-- Generation Time: Nov 15, 2022 at 02:10 PM
-- Server version: 8.0.22-13
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `btnkw8xgenawfvi4xosn`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblclientes`
--

CREATE TABLE `tblclientes` (
  `nombres` varchar(25) NOT NULL,
  `apellidos` varchar(25) NOT NULL,
  `telefono` varchar(15) NOT NULL,
  `direccion` varchar(20) NOT NULL,
  `barrio` varchar(15) NOT NULL,
  `correo` varchar(45) DEFAULT NULL,
  `estado` varchar(10) NOT NULL COMMENT 'Activo, Bloqueado'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `tblclientes`
--

INSERT INTO `tblclientes` (`nombres`, `apellidos`, `telefono`, `direccion`, `barrio`, `correo`, `estado`) VALUES
('Carolina', 'González Estrada', '3013718971', 'Cll 35 #43-19', 'Calle Vieja', NULL, 'Activo'),
('Jhonatan', 'Usuga Florez', '3272093', 'Cll 85 # 90-89', 'Villa Sofía', NULL, 'Activo'),
('Jheison', 'Usuga Flórez  ', '3206620871', 'Cll 85 #90-89', 'Villa Sofía', NULL, 'Activo'),
('Andrés ', 'Castaño Vitola', '3044831076', 'Crr95AA #79-80', 'Paraíso 1', NULL, 'Activo');

-- --------------------------------------------------------

--
-- Table structure for table `tblingredientes`
--

CREATE TABLE `tblingredientes` (
  `cons` int NOT NULL,
  `nombre` varchar(15) NOT NULL,
  `medida` int NOT NULL,
  `costo` int NOT NULL,
  `unidad` varchar(15) NOT NULL,
  `cantidad_disponible` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblingredientes`
--

INSERT INTO `tblingredientes` (`cons`, `nombre`, `medida`, `costo`, `unidad`, `cantidad_disponible`) VALUES
(1, 'Mango', 100, 700, 'gramos', 7),
(2, 'Sal', 500, 800, 'libra', 2),
(3, 'sumo de limón', 1000, 6000, 'litro', 1),
(4, 'soda', 1000, 3000, 'litro', 10),
(5, 'Sirope', 1000, 1000, 'litros', 0),
(6, 'Sal limon', 100, 500, 'gramos', 0),
(7, 'Hielo', 10, 200, 'gramos', 0),
(8, 'Maracuya', 100, 500, 'gramos', 0),
(9, 'Carambola ', 200, 800, 'gramos ', 0),
(10, 'Mora', 500, 2000, 'gramos', 0),
(11, 'Fresa', 500, 1000, 'gramos', 0),
(12, 'Cereza ', 500, 1500, 'gramos', 0),
(13, 'Sandía ', 1000, 900, 'gramos', 0),
(14, 'Azucar', 1000, 2000, 'gramos', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblpedidos`
--

CREATE TABLE `tblpedidos` (
  `cons` int NOT NULL,
  `idproducto` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `cant` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `estado` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT 'pendiente,despachado,cancelado',
  `idcliente` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `idusuario` int NOT NULL,
  `descripcion` varchar(50) NOT NULL,
  `valor` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tblproductos`
--

CREATE TABLE `tblproductos` (
  `cons` int NOT NULL,
  `nombre` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `descripcion` varchar(50) NOT NULL,
  `costo` int NOT NULL,
  `valor` int NOT NULL,
  `descuento` decimal(1,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblproductos`
--

INSERT INTO `tblproductos` (`cons`, `nombre`, `descripcion`, `costo`, `valor`, `descuento`) VALUES
(1, 'Michelada Mango pequeño', 'Soda, mango, sal limón,', 700, 2000, '0'),
(2, 'maracuya', '', 5000, 10000, '0');

-- --------------------------------------------------------

--
-- Table structure for table `tblreceta`
--

CREATE TABLE `tblreceta` (
  `cons` int NOT NULL,
  `consproducto` int NOT NULL,
  `consinsumo` int NOT NULL,
  `cant` float NOT NULL,
  `valor` int NOT NULL,
  `unidad` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `tblreceta`
--

INSERT INTO `tblreceta` (`cons`, `consproducto`, `consinsumo`, `cant`, `valor`, `unidad`) VALUES
(1, 1, 1, 3, 500, 'unidad'),
(2, 1, 4, 100, 3, 'gramos');

-- --------------------------------------------------------

--
-- Table structure for table `tblusuario`
--

CREATE TABLE `tblusuario` (
  `documento` int NOT NULL,
  `correo` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `contraseña` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `perfil` int NOT NULL COMMENT '0=cliente,1=vendedor,2=administrador,3=web master',
  `nombre` varchar(40) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblusuario`
--

INSERT INTO `tblusuario` (`documento`, `correo`, `contraseña`, `perfil`, `nombre`, `telefono`) VALUES
(2922795, 'valentinacoronel735@gmail.com', 'VaNQoL3F2LsIY', 0, 'Valentina Coronel', '3016539477'),
(12334556, 'jheisonuf123@gmail.com', 'JupQSRPk98aF6', 0, 'Juan', '3104079363'),
(50995562, 'andresmchiquito@gmail.com', 'Ye0l91ejrTTTw', 0, 'Yenis Johana Vitola Serpa ', '3117735458'),
(1000768627, 'yosorio452@gmail.com', '1000768627', 0, 'Yorman', '3043438965'),
(1017926066, 'carolinagozaleza435@gmail.com', '1017926066', 2, 'Carolina', NULL),
(1020222939, 'anakarinacg16@gmail.com', '1020222939', 0, 'Ana Karina Castañeda Gómez', '3245887997'),
(1025884958, 'jgallegocasas201@gmail.com', 'Ju53FzVvUvuXw', 0, 'Juan Manuel Gallego', '3025614735'),
(1032010812, 'jhonatanusuga.10@gmail.com', '1032010812', 3, 'Jhonatan', '3014412201'),
(1033487792, 'andresvitola1808@gmail.com', '1033487792', 1, 'Andrés', NULL),
(1034917575, 'lara24arb@gmail.com', 'LaoAOf8O/fncY', 0, 'Laura', '3004816572'),
(1034919764, 'mq3402248@gmail.com', 'MadnKOck4CAm.', 0, 'Maicol', '3017802664'),
(1038100435, 'reynalgh1@gmail.com', '108HC1tlayg4M', 0, 'Yostin Gonzalez', '3148713151'),
(1071348334, 'jogecano8@gmail.com', '1071348334', 0, 'Jorge', '3134149696');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblingredientes`
--
ALTER TABLE `tblingredientes`
  ADD PRIMARY KEY (`cons`);

--
-- Indexes for table `tblpedidos`
--
ALTER TABLE `tblpedidos`
  ADD PRIMARY KEY (`cons`);

--
-- Indexes for table `tblproductos`
--
ALTER TABLE `tblproductos`
  ADD PRIMARY KEY (`cons`);

--
-- Indexes for table `tblreceta`
--
ALTER TABLE `tblreceta`
  ADD PRIMARY KEY (`cons`);

--
-- Indexes for table `tblusuario`
--
ALTER TABLE `tblusuario`
  ADD PRIMARY KEY (`documento`),
  ADD UNIQUE KEY `Correo` (`correo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblingredientes`
--
ALTER TABLE `tblingredientes`
  MODIFY `cons` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tblpedidos`
--
ALTER TABLE `tblpedidos`
  MODIFY `cons` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblproductos`
--
ALTER TABLE `tblproductos`
  MODIFY `cons` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblreceta`
--
ALTER TABLE `tblreceta`
  MODIFY `cons` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
