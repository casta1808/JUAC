         <section class="page-section bg-primary text-white mb-0" id="reseña">
            <div class="container">
                <!-- About Section Heading-->
                <h2 class="page-section-heading text-center text-uppercase text-white">RESEÑA HISTÓRICA</h2>
                <!-- Icon Divider-->
                <div class="divider-custom divider-light">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                <!-- About Section Content-->
              <div class="text-center">
                  Hace unos meses atrás nace el problema de tener que hacer un emprendimiento en nuestra institución. Mi amigo Andrés Castaño y yo tomamos la iniciativa de hacer bebidas tipo micheladas con gaseosas, pero creimos que esto no sería tan llamativo para los clientes. Andrés se le ocurre la gran idea de realizar las micheladas, pero ahora ¡CON FRUTAS!.

Empezamos a platearnos de qué sabores podrían ser las bebidas y concordamos que las bebidas de maracuyá, mango, maracu-mango, frutos rojos y sandía serían las que manejaríamos en nuestro emprendimiento.

Decidimos ponerle el nombre con algo que nos indentificará y en lo primero que pensamos fue las iniciales de nuestros nombres. Entonces nuestra empresa quedó con el nombre JU&AC.</p>
                </div>
                <!-- About Section Button-->
                
            </div>
        </section>