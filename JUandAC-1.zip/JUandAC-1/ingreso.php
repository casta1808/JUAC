<section class="page-section bg-primary" id="ingreso">
<div></div>
<main class="login-form">
<div class="container">
  <h2 class="page-section-heading text-center text-uppercase text-white">LOGIN</h2><br>
  <div class="divider-custom divider-light">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
<div class="card">
<div class="card-header">
<div class="card-body">
<form name="login" action="index.php" method="post">
<div class="form-group row">
    <label class="col-md-4-col-form-label text-md-right">Documento
    </label>
  <div class="col-md-6">
    
      <input type="text" 
        class="form-control"
        name="usuario"  id="nombre_usuario"
        maxlength="20"
        size="20">
    
    <label class="col-md-4-col-form-label text-md-right">Contraseña
    </label>
    <div class="col-md-6">
      <input type="password"
        id="password"
        class="form-control"
        name="clave" id="clave_usuario"
        maxlength="20"
        size="20">
  </div>



  <div class ="col-md-6 offset-md-4">
   <br><button type="submit" value="entrar" class="btn btn-primary">Enviar
 </button><br><br>
</div>
</form>
  
   </div></div></div>
</main>
</section>

