<section class="page-section bg-primary text-white mb-0" id="contacto">
<footer class="footer text-center">
            <div class="container">
                <div class="row">
                    <!-- Footer Location-->
                    <div class="col-lg-4 mb-5 mb-lg-0">
                        <h4 class="text-uppercase mb-4">Dirección</h4>
                        <p class="lead mb-0">
                            Calle 85#90-89
                            <br />
                            Villa Sofía
                        </p>
                    </div>
                    <!-- Footer Social Icons-->
                   <!-- <div class="col-lg-4 mb-5 mb-lg-0"> -->
<div class="col"> 
                  <a href= "https://wa.link/3g9qg9">WHASAPP</a> <br><br>
                    <img src= "img/codigo.png" class="qr"> 

                    
                    </div>
                    <!-- Footer About Text-->
                    <div class="col-lg-4">
                        <h4 class="text-uppercase mb-4">Contactanos</h4>
                        <p class="lead mb-0">
                            +57 304-483-1076 <br>
                            
                          
  
  
                          <br>
                           De 6:00 PM a 3:00 A.M
                            
                        </p>
                    </div>
                </div>
            </div>
        </footer>
</section>