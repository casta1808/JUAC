<?
session_start();
$usuario=$_POST['usuario'];
$clave=$_POST['clave'];
$usuario= trim($usuario);
$clave=trim($clave);
if(isset($usuario)&& isset($clave) ){
include 'config/conexion.php';
  // al guargar lo crea con el nombre
  $salt=substr($usuario,0,2);
  /*Revisar la clave al guardad*/
  $clave_crypt=crypt($clave,$salt);
  $sql="SELECT documento, contraseña, perfil, nombre FROM tblusuario WHERE documento='$usuario' AND contraseña='$clave_crypt'";
  echo ' '.$sql;
  $consulta=mysqli_query($con,$sql) or die("Error ".$sql);
  $nfilas=mysqli_num_rows($consulta);
  while($reg=mysqli_fetch_array($consulta)){
    $_SESSION ["usuario_valido"]=$reg['nombre'];
    $_SESSION ["perfil"]=$reg['perfil'];
    $usuario_valido=$reg['nombre'];
    echo '<br>Ya ingresó'.$clave_crypt;
  }
  mysqli_close($con);
}
  if($nfilas>0){
    $usuario_valido=$usuario;
    $_SESSION['usuario_valido']=$usuario_valido;
  }
    


?>

<!DOCTYPE html>
<html lang="en">
  
    <?
include 'head.php';
?>
<?
include 'menu.php';
?>
        <!-- Masthead-->
        <header class="masthead bg-primary text-white text-center">
            <div class="container d-flex align-items-center flex-column">
                <!-- Masthead Avatar Image-->
                <video src="img/logo.mp4" alt="Michelada" width="300" height="300" autoplay muted loop>hola</video>
                <!-- Masthead Heading-->
               <br> <h1 class="masthead-heading text-uppercase mb-0">JU&AC</h1>
                <!-- Icon Divider-->
                <div class="divider-custom divider-light">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                <!-- Masthead Subheading-->
                <p class="masthead-subheading font-weight-light mb-0">Pa' los gustos los sabores.</p>
            </div>
        </header>
        <!-- Portfolio Section-->
       <?
include 'productos.php';
?>
        <!-- About Section-->
<?
include 'reseña.php';
?>

<?
include 'mision.php';
?>

<?
include 'vision.php';
?>

<?
include 'justificacion.php';
?>

<?
include 'filosofia.php';
?>
<?
include 'login.php'
?>
<?
include 'config/conexion.php'
?>
<?
include 'ingreso.php'
?>
<?
include 'contacto.php'
?>
 <? if(isset($_SESSION["usuario_valido"])&& ($_SESSION['perfil'])=='1'){
           include 'lista_usuarios.php';
             }?>
        <!-- Footer-->
       
        <!-- Copyright Section-->
        <div class="copyright py-4 text-center text-white">
            <div class="container"><small>Copyright &copy; JU&AC</small></div>
        </div>
        <!-- Portfolio Modals-->
        <!-- Portfolio Modal 1-->
        <div class="portfolio-modal modal fade" id="portfolioModal1" tabindex="-1" aria-labelledby="portfolioModal1" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header border-0"><button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button></div>
                    <div class="modal-body text-center pb-5">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-8">
                                    <!-- Portfolio Modal - Title-->
                                    <h2 class="portfolio-modal-title text-secondary text-uppercase mb-0">Maracumango</h2>
                                    <!-- Icon Divider-->
                                    <div class="divider-custom">
                                        <div class="divider-custom-line"></div>
                                        <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                                        <div class="divider-custom-line"></div>
                                    </div>
                                    <!-- Portfolio Modal - Image-->
                                    <img class="img-fluid rounded mb-5" src="img/primera.png" height="200" width="200" alt="..." />
                                    <!-- Portfolio Modal - Text-->
                                    <p> $4.000</p>
                                    <button class="btn btn-primary" data-bs-dismiss="modal">
                                        <img src="img/carrito.png" height="20" width="20">
                                        <a href= "https://wa.link/8u22qz"  class="text-white">Pedir</a>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Portfolio Modal 2-->
        <div class="portfolio-modal modal fade" id="portfolioModal2" tabindex="-1" aria-labelledby="portfolioModal2" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header border-0"><button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button></div>
                    <div class="modal-body text-center pb-5">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-8">
                                    <!-- Portfolio Modal - Title-->
                                    <h2 class="portfolio-modal-title text-secondary text-uppercase mb-0">Mango</h2>
                                    <!-- Icon Divider-->
                                    <div class="divider-custom">
                                        <div class="divider-custom-line"></div>
                                        <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                                        <div class="divider-custom-line"></div>
                                    </div>
                                    <!-- Portfolio Modal - Image-->
                                    <img class="img-fluid rounded mb-5" src="img/segunda.png" height="200" width="200" alt="..." /> 
                                    <!-- Portfolio Modal - Text-->
                                    <p class="mb-4">$4.000</p>
                                    <button class="btn btn-primary" data-bs-dismiss="modal">
                                      <img src="img/carrito.png" height="20" width="20">
                                        <a href= "https://wa.link/qdqjv4" class="text-white">Pedir</a>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Portfolio Modal 3-->
        <div class="portfolio-modal modal fade" id="portfolioModal3" tabindex="-1" aria-labelledby="portfolioModal3" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header border-0"><button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button></div>
                    <div class="modal-body text-center pb-5">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-8">
                                    <!-- Portfolio Modal - Title-->
                                    <h2 class="portfolio-modal-title text-secondary text-uppercase mb-0">Maracuyá</h2>
                                    <!-- Icon Divider-->
                                    <div class="divider-custom">
                                        <div class="divider-custom-line"></div>
                                        <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                                        <div class="divider-custom-line"></div>
                                    </div>
                                    <!-- Portfolio Modal - Image-->
                                    <img class="img-fluid rounded mb-5" src="img/quinta.png" height="200" width="200" alt="..." />
                                    <!-- Portfolio Modal - Text-->
                                    <p class="mb-4">$4.000</p>
                                    <button class="btn btn-primary" data-bs-dismiss="modal">
                                        <img src="img/carrito.png" height="20" width="20">
                                        <a href= "https://wa.link/bot4eg"  class="text-white">Pedir</a>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Portfolio Modal 4-->
        <div class="portfolio-modal modal fade" id="portfolioModal4" tabindex="-1" aria-labelledby="portfolioModal4" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header border-0"><button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button></div>
                    <div class="modal-body text-center pb-5">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-8">
                                    <!-- Portfolio Modal - Title-->
                                    <h2 class="portfolio-modal-title text-secondary text-uppercase mb-0">Cereza</h2>
                                    <!-- Icon Divider-->
                                    <div class="divider-custom">
                                        <div class="divider-custom-line"></div>
                                        <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                                        <div class="divider-custom-line"></div>
                                    </div>
                                    <!-- Portfolio Modal - Image-->
                                    <img class="img-fluid rounded mb-5" src="img/cuarta.png" height="200" width="200" alt="..." />
                                    <!-- Portfolio Modal - Text-->
                                    <p class="mb-4">$4.000</p>
                                    
                                    
                                    <button class="btn btn-primary" data-bs-dismiss="modal">
                                        <img src="img/carrito.png" height="20" width="20">
                                      <a href= "https://wa.link/e80qty"  class="text-white">Pedir</a>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Portfolio Modal 5-->
        <div class="portfolio-modal modal fade" id="portfolioModal5" tabindex="-1" aria-labelledby="portfolioModal5" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header border-0"><button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button></div>
                    <div class="modal-body text-center pb-5">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-8">
                                    <!-- Portfolio Modal - Title-->
                                    <h2 class="portfolio-modal-title text-secondary text-uppercase mb-0">Frutos rojos</h2>
                                    <!-- Icon Divider-->
                                    <div class="divider-custom">
                                        <div class="divider-custom-line"></div>
                                        <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                                        <div class="divider-custom-line"></div>
                                    </div>
                                    <!-- Portfolio Modal - Image-->
                                    <img class="img-fluid rounded mb-5" src="img/tercera.png" height="200" width="200" alt="..." />
                                    <!-- Portfolio Modal - Text-->
                                    <p class="mb-4">$4.000</p>
                                    <button class="btn btn-primary" data-bs-dismiss="modal">
                                        <img src="img/carrito.png" height="20" width="20">
                                       <a href= "https://wa.link/splm8c"  class="text-white">Pedir</a>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Portfolio Modal 6-->
        <div class="portfolio-modal modal fade" id="portfolioModal6" tabindex="-1" aria-labelledby="portfolioModal6" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header border-0"><button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button></div>
                    <div class="modal-body text-center pb-5">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-8">
                                    <!-- Portfolio Modal - Title-->
                                    <h2 class="portfolio-modal-title text-secondary text-uppercase mb-0">Sandia</h2>
                                    <!-- Icon Divider-->
                                    <div class="divider-custom">
                                        <div class="divider-custom-line"></div>
                                        <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                                        <div class="divider-custom-line"></div>
                                    </div>
                                    <!-- Portfolio Modal - Image-->
                                    <img class="img-fluid rounded mb-5" src="img/sexta.png" height="200" width="200" alt="..." />
                                    <!-- Portfolio Modal - Text-->
                                    <p class="mb-4">$4.000/p>
                                    <button class="btn btn-primary" data-bs-dismiss="modal">
                                        <img src="img/carrito.png" height="20" width="20">
                                        <a href= "https://wa.link/mfs1ss"  class="text-white">Pedir</a>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <!-- * *                               SB Forms JS                               * *-->
        <!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>
    </body>
</html>
