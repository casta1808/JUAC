  <?
$host="";
$user="";
$password="";
$db="";
$con=mysqli_connect($host,$user,$password,$db) or
  die ("Error en la conexión");
?>